/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "mpu6050.h"
#include "Anglas_LCD_I2C.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define BUFFER_LEN  1
#define CHA GPIO_PIN_1
#define CHB GPIO_PIN_2
#define PI 3.14159265358979323846
#define MIN_DUTY_CYCLE 10800 // Corresponds to 30%
#define MAX_DUTY_CYCLE 36000 // Corresponds to 100%
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
uint8_t RX_BUFFER[BUFFER_LEN] = {0};
uint16_t CH1DC = 0;
int DC_Servo = 73;


float counter_act = 0;
float counter_ant = 0;
float RPM = 0;
float num_pulses = 0;
float speed = 0;
float dist = 0;
int speed_int = 0;
int tiempo = 0;

// PID parameters
float setpoint = 30.0;
float desired_angle = 0;
float Kp = 25.3314; // Proportional gain
float Ki = 1.4598; // Integral gain
float Kd = 0.0;
float Kp_dir = 5.0;
float Ki_dir = 0.0;
float Kd_dir = 0.0;
float error = 0;
float error_dir = 0;
float lastError = 0;
float lastError_dir = 0;
float ErrorAcum = 0;
float ErrorAcum_dir = 0;
float ErrorRate = 0;
float ErrorRate_dir = 0;
uint32_t previousTime = 0;
uint32_t previousTime_dir = 0;

#define TRIG_PIN GPIO_PIN_15
#define TRIG_PORT GPIOB
#define ECHO_PIN GPIO_PIN_4
#define ECHO_PORT GPIOB
uint32_t pMillis;
uint32_t Value1 = 0;
uint32_t Value2 = 0;
int distObj  = 0;  // cm

// MPU6050
float ax, ay, az, gx, gy, gz, t;
float axAng = 0, ayAng = 0, azAng = 0, gxAng = 0, gyAng = 0, gzAng = 0;
float AcellRoll = 0, AcellPitch = 0, AcellYaw = 0;
float AngleRoll = 0, AnglePitch = 0, AngleYaw = 0;
float sumax = 0, sumay = 0, sumaz = 0, sumgx = 0, sumgy = 0, sumgz = 0;

char buff[16];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
//int32_t ControlPID(float currentSpeed, float setpoint, float *lastError, float *ErrorAcum, uint32_t *previousTime, uint16_t *dutyCycle);
void ControlPID(float currentSpeed, float setpoint, float *lastError, float *ErrorAcum, uint32_t *previousTime);
void PID_dir(float currentAngle, float desiredAngle, float *lastError, float *ErrorAcum, uint32_t *previousTime);
void handleMotorControl(void);
int ultrasonic(void);
void Stop(void);
void ReadMPU(float *ax, float *ay, float *az, float *gx, float *gy, float *gz);
void MPU_CAL(void);
void MPU_VAL(void);
void AngleGyr(void);
void AngleAcc(void);
float Direction(void);
void LCD(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_TIM1_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();
  MX_USART1_UART_Init();
  MX_USART3_UART_Init();
  MX_TIM4_Init();
  MPU6050_Init();
  LCD_I2C_Init();
  /* USER CODE BEGIN 2 */
  //  MPU6050_Init();
  //  LCD_I2C_Init();

  // Enable UART receive interrupt
    HAL_UART_Receive_IT(&huart1, RX_BUFFER, BUFFER_LEN); //Start receiving data in the UART-1

    // Start PWM with initial duty cycle
    HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_1);
    HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_2);


    // Start Internal Timer
    HAL_TIM_Base_Start_IT(&htim1);

    HAL_TIM_Base_Start(&htim2);
    HAL_GPIO_WritePin(TRIG_PORT, TRIG_PIN, GPIO_PIN_RESET);  // pull the TRIG pin low

    //
    HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_1);
    DC_Servo = 73;

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
    MPU_CAL();
  while (1)
  {
	  handleMotorControl();

	  ultrasonic();

	  ReadMPU(&ax, &ay, &az, &gx, &gy, &gz);
	  LCD();

	  //TIM4->CCR1 = DC_Servo*720/1000;

	  float currentAngle = Direction();
	  PID_dir(currentAngle, desired_angle, &lastError_dir, &ErrorAcum_dir, &previousTime_dir);
	  ControlPID(speed, setpoint, &lastError, &ErrorAcum, &previousTime);


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance == huart1.Instance)
	{
	HAL_UART_Receive_IT(&huart1, RX_BUFFER, BUFFER_LEN);
	}
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	UNUSED(GPIO_Pin); // This section is kept
	if (HAL_GPIO_ReadPin(CHB_GPIO_Port,CHB_Pin) == GPIO_PIN_RESET)
		{
		counter_act ++;
		}
	else
		{
		counter_act --;
		}
    dist = (counter_act*PI*7)/170;
}

/* Motor control function */
void handleMotorControl(void)
{

    // Process received command

	if (RX_BUFFER[0] == 'F')
	{
		//TIM3->CCR1 = CH1DC;
		// Set the new PWM duty cycle to control the motor speed
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_SET);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
		HAL_UART_Transmit(&huart1, (const uint8_t *)"FORWARD", 7, 1000);
	}
	else if (RX_BUFFER[0] == 'R')
	{
		//TIM3->CCR1 = CH1DC;
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET);
		HAL_UART_Transmit(&huart1, (const uint8_t *)"REVERSE", 7, 1000);
	}
	else if (RX_BUFFER[0] == 'S')
	{
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET);
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET);
		HAL_UART_Transmit(&huart1, (const uint8_t *)"STOP", 4, 1000);
	}

}

/*
int32_t ControlPID(float speed, float setpoint, float *lastError, float *ErrorAcum, uint32_t *previousTime, uint16_t *dutyCycle)
{
    // GET TIME
    uint32_t currentTime = HAL_GetTick(); // Get current system time in milliseconds
    float elapsedTime = (float)(currentTime - *previousTime)/1000.0f; // Calculate elapsed time

    // GET ERROR
    float error = setpoint - speed; // Calculate the current error

    // GET ACCUMULATED ERROR
    // NOTE: use int32 or float type, do not mix with unsigned int
    // Divide by 1000.0 to get seconds
    *ErrorAcum += error * elapsedTime;

    // GET ERROR RATE
    float ErrorRate = (error - *lastError) / elapsedTime; // Derivative error

    // PID control output
    int32_t controlOutput = (int32_t)(Kp * error + Ki * *ErrorAcum + Kd * ErrorRate);

    // UPDATE VARIABLES
    *lastError = error;
    *previousTime = currentTime;

    // Update duty cycle
    *dutyCycle += controlOutput;


    // Constrain duty cycle within limits
    if (*dutyCycle > MAX_DUTY_CYCLE)
        *dutyCycle = MAX_DUTY_CYCLE;
    if (*dutyCycle < MIN_DUTY_CYCLE)
        *dutyCycle = MIN_DUTY_CYCLE;

    //CH1DC += CV_out;

    //TIM2->CCR1=CH1DC;

    return *dutyCycle;
}
*/

void ControlPID(float speed, float setpoint, float *lastError, float *ErrorAcum, uint32_t *previousTime)
{
    // GET TIME
    uint32_t currentTime = HAL_GetTick(); // Get current system time in milliseconds
    float elapsedTime = (float)(currentTime - *previousTime)/1000.0f; // Calculate elapsed time

    // GET ERROR
    float error = setpoint - speed; // Calculate the current error

    // GET ACCUMULATED ERROR
    // NOTE: use int32 or float type, do not mix with unsigned int
    // Divide by 1000.0 to get seconds
    *ErrorAcum += error * elapsedTime;

    // GET ERROR RATE
    float ErrorRate = (error - *lastError) / elapsedTime; // Derivative error

    // PID control output
    int32_t controlOutput = (int32_t)(Kp * error + Ki * *ErrorAcum + Kd * ErrorRate);

    // UPDATE VARIABLES
    *lastError = error;
    *previousTime = currentTime;

    // Update duty cycle
    CH1DC += controlOutput;

    // Constrain duty cycle within limits
    if (CH1DC > MAX_DUTY_CYCLE)
        CH1DC = MAX_DUTY_CYCLE;
    if (CH1DC < MIN_DUTY_CYCLE)
        CH1DC = MIN_DUTY_CYCLE;

    TIM3->CCR1=CH1DC;

}


void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	//MPU_CAL();
	if (htim->Instance == TIM1)
	{
		num_pulses = counter_act - counter_ant;
		RPM = num_pulses * (600/280);
		counter_ant = counter_act;
		speed = (RPM*PI*6)/60;
		speed_int = (int)(speed*10);

		//CH1DC = ControlPID(speed, setpoint, &lastError, &ErrorAcum, &previousTime, &CH1DC);

    	//if (CH1DC > MAX_DUTY_CYCLE) CH1DC = MAX_DUTY_CYCLE;
    	//if (CH1DC < MIN_DUTY_CYCLE) CH1DC = MIN_DUTY_CYCLE;

		// Set the new PWM duty cycle to control the motor speed
		//__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, CH1DC);

	}
}

int ultrasonic()
{
	HAL_GPIO_WritePin(TRIG_PORT, TRIG_PIN, GPIO_PIN_SET);  // pull the TRIG pin HIGH
	__HAL_TIM_SET_COUNTER(&htim2, 0);
	while (__HAL_TIM_GET_COUNTER (&htim2) < 10);  // wait for 10 us
	HAL_GPIO_WritePin(TRIG_PORT, TRIG_PIN, GPIO_PIN_RESET);  // pull the TRIG pin low

	pMillis = HAL_GetTick(); // used this to avoid infinite while loop  (for timeout)
	// wait for the echo pin to go high
	while (!(HAL_GPIO_ReadPin (ECHO_PORT, ECHO_PIN)) && pMillis + 10 >  HAL_GetTick());
	Value1 = __HAL_TIM_GET_COUNTER (&htim2);

	pMillis = HAL_GetTick(); // used this to avoid infinite while loop (for timeout)
	// wait for the echo pin to go low
	while ((HAL_GPIO_ReadPin (ECHO_PORT, ECHO_PIN)) && pMillis + 50 > HAL_GetTick());
	Value2 = __HAL_TIM_GET_COUNTER (&htim2);

	distObj = (Value2-Value1)* 0.034/2;

	if (distObj < 20)
	{
		Stop();
	}

	//HAL_Delay(50);

	return distObj;
}


void Stop()
{
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0);
}

void ReadMPU(float *ax, float *ay, float *az, float *gx, float *gy, float *gz){
	if(MPU6050_Read_Data() > 0)
	{
  		*ax = MPU6050_Get_Ax();
	    *ay = MPU6050_Get_Ay();
	    *az = MPU6050_Get_Az();
	    *gx = MPU6050_Get_Gx();
	    *gz = MPU6050_Get_Gy();
	    *gy = MPU6050_Get_Gz();
	}
}

// Función para leer el giroscopio y promediar las lecturas
void MPU_CAL(){
    int numSamples = 4000;

    for (int i = 0; i < numSamples; i++) {
            if(MPU6050_Read_Data() > 0)
            {
            	gx = MPU6050_Get_Gx();
            	gz = MPU6050_Get_Gy();
            	gy = MPU6050_Get_Gz();
            	sumgx += gx;
            	sumgy += gy;
            	sumgz += gz;
                HAL_Delay(1); // Pequeña pausa para dar tiempo al sensor
            }
        }
    // Calcular el promedio de las lecturas
    sumgx /= numSamples;
    sumgy /= numSamples;
    sumgz /= numSamples;
}

void MPU_VAL(){
	ax -= sumax;
	ay -= sumay;
	az -= sumaz;
	gx -= sumgx;
	gy -= sumgy;
	gz -= sumgz;

	if (gx<1 && gx>-1){
		gx = 0;
	}

	if (gy<1 && gy>-1){
		gy = 0;
	}

	if (gz<1 && gz>-1){
		gz = 0;
	}
}

void AngleGyr()
{
    // Calcular el delta de tiempo (dt)
    static uint32_t prevTime = 0;
    uint32_t currentTime = HAL_GetTick();
    float dt = (currentTime - prevTime) / 1000.0; // Tiempo en segundos
    prevTime = currentTime;

    gxAng += gx * dt; // Integración para calcular el ángulo
    gyAng += gy * dt;
    gzAng += gz * dt;
}

void AngleAcc() {
    // Supongamos que tienes lecturas actualizadas de ax, ay, az
    axAng = atan2f(ay, sqrt(ax * ax + az * az)) * (180.0 / PI);
    ayAng = atan2f(-ax, sqrt(ay * ay + az * az)) * (180.0 / PI);
    azAng = atan2f(sqrt(ax * ax + ay * ay),az) * (180.0 / PI);
}

float Direction() {
	float alpha = 0.01;
    // Leer datos del MPU6050
	MPU_VAL();

    // Aplicar un filtro si es necesario
    //LowPassFilter(&ax, &ay, &az, &prevAx, &prevAy, &prevAz);

    // Calcular los ángulos del acelerómetro
    AngleAcc();

    // Calcular el ángulo del giroscopio y fusionar con el filtro complementario si es necesario
    AngleGyr();

    // Aplicar el filtro complementario
    AngleRoll = gxAng * (1 - alpha) + axAng * alpha;
    AnglePitch = gyAng * (1 - alpha) + ayAng * alpha;
    AngleYaw = gzAng * (1 - alpha) + azAng * alpha;

    return AngleYaw;
}


void PID_dir(float currentAngle, float desiredAngle, float *lastError, float *ErrorAcum, uint32_t *previousTime){

	uint32_t currentTime = HAL_GetTick();

	float elapsedTime = (float)(currentTime - *previousTime)/1000.0f;

	float error = desiredAngle - currentAngle;

	*ErrorAcum += error * elapsedTime;

	int controlOutput = (int)(Kp_dir * error + Ki_dir *(*ErrorAcum) + Kd_dir * ErrorRate);

	*lastError = error;
	*previousTime = currentTime;

	DC_Servo = 73 - controlOutput;

	if (DC_Servo > 100){
		DC_Servo = 100;
	}
	else if (DC_Servo < 55){
		DC_Servo = 55;
	}

	TIM4->CCR1 = DC_Servo*720/1000;;

}

void LCD(){
	sprintf(buff, "Speed: %4.2f", speed);
	LCD_I2C_WriteText(1,1,buff);

	sprintf(buff, "Distance: %4.2f", dist);
	LCD_I2C_WriteText(2,1,buff);
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
